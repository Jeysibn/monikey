--
-- PostgreSQL database dump
--

\restrict hA7j2oDaKR2nVbBjaLrwSWLykOXvddP9eUf2dtyjNjIWfevGbJ2fh7OAdlXugwA

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: account_classification; Type: TYPE; Schema: public; Owner: monikey
--

CREATE TYPE public.account_classification AS ENUM (
    'asset',
    'liability'
);


ALTER TYPE public.account_classification OWNER TO monikey;

--
-- Name: account_type; Type: TYPE; Schema: public; Owner: monikey
--

CREATE TYPE public.account_type AS ENUM (
    'checking',
    'savings',
    'ewallet',
    'cash',
    'credit_card'
);


ALTER TYPE public.account_type OWNER TO monikey;

--
-- Name: balance_effect_role; Type: TYPE; Schema: public; Owner: monikey
--

CREATE TYPE public.balance_effect_role AS ENUM (
    'source',
    'destination',
    'expense',
    'income',
    'card_charge',
    'card_payment',
    'fee'
);


ALTER TYPE public.balance_effect_role OWNER TO monikey;

--
-- Name: card_network; Type: TYPE; Schema: public; Owner: monikey
--

CREATE TYPE public.card_network AS ENUM (
    'visa',
    'mastercard'
);


ALTER TYPE public.card_network OWNER TO monikey;

--
-- Name: investment_trade_type; Type: TYPE; Schema: public; Owner: monikey
--

CREATE TYPE public.investment_trade_type AS ENUM (
    'buy',
    'sell'
);


ALTER TYPE public.investment_trade_type OWNER TO monikey;

--
-- Name: notification_status; Type: TYPE; Schema: public; Owner: monikey
--

CREATE TYPE public.notification_status AS ENUM (
    'pending',
    'sending',
    'sent',
    'failed'
);


ALTER TYPE public.notification_status OWNER TO monikey;

--
-- Name: recurring_frequency; Type: TYPE; Schema: public; Owner: monikey
--

CREATE TYPE public.recurring_frequency AS ENUM (
    'weekly',
    'monthly',
    'yearly'
);


ALTER TYPE public.recurring_frequency OWNER TO monikey;

--
-- Name: recurring_status; Type: TYPE; Schema: public; Owner: monikey
--

CREATE TYPE public.recurring_status AS ENUM (
    'active',
    'paused'
);


ALTER TYPE public.recurring_status OWNER TO monikey;

--
-- Name: transaction_source; Type: TYPE; Schema: public; Owner: monikey
--

CREATE TYPE public.transaction_source AS ENUM (
    'manual',
    'ocr',
    'recurring',
    'import'
);


ALTER TYPE public.transaction_source OWNER TO monikey;

--
-- Name: transaction_status; Type: TYPE; Schema: public; Owner: monikey
--

CREATE TYPE public.transaction_status AS ENUM (
    'cleared',
    'pending'
);


ALTER TYPE public.transaction_status OWNER TO monikey;

--
-- Name: transaction_type; Type: TYPE; Schema: public; Owner: monikey
--

CREATE TYPE public.transaction_type AS ENUM (
    'income',
    'expense',
    'transfer'
);


ALTER TYPE public.transaction_type OWNER TO monikey;

--
-- Name: enforce_credit_card_details_invariants(); Type: FUNCTION; Schema: public; Owner: monikey
--

CREATE FUNCTION public.enforce_credit_card_details_invariants() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    acct_classification "account_classification";
    acct_type "account_type";
    owed BIGINT;
BEGIN
    SELECT fa."classification", fa."account_type", fa."current_balance_minor"
    INTO acct_classification, acct_type, owed
    FROM "financial_accounts" fa
    WHERE fa."id" = NEW."account_id";

    IF acct_classification IS NULL THEN
        RAISE EXCEPTION 'UNKNOWN_ACCOUNT: credit_card_details.account_id % does not reference an existing financial_accounts row', NEW."account_id";
    END IF;

    IF acct_classification <> 'liability' OR acct_type <> 'credit_card' THEN
        RAISE EXCEPTION 'CATEGORY_NOT_ALLOWED: credit_card_details.account_id % must reference a liability/credit_card account (got classification=%, account_type=%)',
            NEW."account_id", acct_classification, acct_type;
    END IF;

    IF owed < 0 OR owed > NEW."credit_limit_minor" THEN
        RAISE EXCEPTION 'CREDIT_LIMIT_EXCEEDED: card % owed % exceeds bounds [0, %]',
            NEW."account_id", owed, NEW."credit_limit_minor";
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.enforce_credit_card_details_invariants() OWNER TO monikey;

--
-- Name: enforce_financial_account_card_invariants(); Type: FUNCTION; Schema: public; Owner: monikey
--

CREATE FUNCTION public.enforce_financial_account_card_invariants() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    card_limit BIGINT;
    orphaned_details_count INTEGER;
BEGIN
    IF NEW."classification" <> 'liability' OR NEW."account_type" <> 'credit_card' THEN
        SELECT COUNT(*) INTO orphaned_details_count
        FROM "credit_card_details" ccd
        WHERE ccd."account_id" = NEW."id";

        IF orphaned_details_count > 0 THEN
            RAISE EXCEPTION 'CATEGORY_NOT_ALLOWED: account % cannot be reclassified away from credit_card/liability while a credit_card_details row still references it; delete the details row in the same transaction first', NEW."id";
        END IF;

        RETURN NEW;
    END IF;

    SELECT ccd."credit_limit_minor" INTO card_limit
    FROM "credit_card_details" ccd
    WHERE ccd."account_id" = NEW."id";

    IF card_limit IS NULL THEN
        RAISE EXCEPTION 'UNKNOWN_ACCOUNT: credit_card/liability account % has no matching credit_card_details row', NEW."id";
    END IF;

    IF NEW."current_balance_minor" < 0 OR NEW."current_balance_minor" > card_limit THEN
        RAISE EXCEPTION 'CREDIT_LIMIT_EXCEEDED: card % owed % exceeds bounds [0, %]',
            NEW."id", NEW."current_balance_minor", card_limit;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.enforce_financial_account_card_invariants() OWNER TO monikey;

--
-- Name: prevent_orphaning_live_credit_card(); Type: FUNCTION; Schema: public; Owner: monikey
--

CREATE FUNCTION public.prevent_orphaning_live_credit_card() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    acct_still_card BOOLEAN;
BEGIN
    SELECT (fa."account_type" = 'credit_card') INTO acct_still_card
    FROM "financial_accounts" fa
    WHERE fa."id" = OLD."account_id";

    IF acct_still_card THEN
        RAISE EXCEPTION 'CATEGORY_NOT_ALLOWED: cannot delete credit_card_details for account % while it remains a credit_card account; archive or reclassify the account first', OLD."account_id";
    END IF;

    RETURN OLD;
END;
$$;


ALTER FUNCTION public.prevent_orphaning_live_credit_card() OWNER TO monikey;

--
-- Name: update_import_batches_updated_at(); Type: FUNCTION; Schema: public; Owner: monikey
--

CREATE FUNCTION public.update_import_batches_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW."updated_at" = now();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_import_batches_updated_at() OWNER TO monikey;

--
-- Name: update_plaid_items_updated_at(); Type: FUNCTION; Schema: public; Owner: monikey
--

CREATE FUNCTION public.update_plaid_items_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW."updated_at" = now();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_plaid_items_updated_at() OWNER TO monikey;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: monikey
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW."updated_at" = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO monikey;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO monikey;

--
-- Name: budget_allocations; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.budget_allocations (
    id uuid NOT NULL,
    budget_period_id uuid NOT NULL,
    category_id uuid NOT NULL,
    allocated_minor bigint NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.budget_allocations OWNER TO monikey;

--
-- Name: budget_periods; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.budget_periods (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    income_pool_minor bigint DEFAULT 0 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.budget_periods OWNER TO monikey;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.categories (
    id uuid NOT NULL,
    user_id uuid,
    name text NOT NULL,
    color text NOT NULL,
    budgetable boolean DEFAULT true NOT NULL,
    allows_income boolean DEFAULT false NOT NULL,
    allows_expense boolean DEFAULT true NOT NULL,
    archived_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT categories_allows_income_or_expense_chk CHECK ((allows_income OR allows_expense))
);


ALTER TABLE public.categories OWNER TO monikey;

--
-- Name: credit_card_details; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.credit_card_details (
    account_id uuid NOT NULL,
    network public.card_network NOT NULL,
    credit_limit_minor bigint NOT NULL,
    due_day integer NOT NULL,
    minimum_payment_minor bigint DEFAULT 0 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT credit_card_details_credit_limit_positive_chk CHECK ((credit_limit_minor > 0)),
    CONSTRAINT credit_card_details_due_day_chk CHECK (((due_day >= 1) AND (due_day <= 31))),
    CONSTRAINT credit_card_details_min_payment_non_negative_chk CHECK ((minimum_payment_minor >= 0))
);


ALTER TABLE public.credit_card_details OWNER TO monikey;

--
-- Name: daily_finance_snapshots; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.daily_finance_snapshots (
    user_id uuid NOT NULL,
    snapshot_date date NOT NULL,
    asset_total_minor bigint DEFAULT 0 NOT NULL,
    liability_total_minor bigint DEFAULT 0 NOT NULL,
    net_worth_minor bigint DEFAULT 0 NOT NULL,
    card_debt_minor bigint DEFAULT 0 NOT NULL,
    base_currency character(3) DEFAULT 'PHP'::bpchar NOT NULL,
    generated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.daily_finance_snapshots OWNER TO monikey;

--
-- Name: dividends; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.dividends (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    instrument_id uuid NOT NULL,
    amount_minor bigint NOT NULL,
    occurred_on date NOT NULL,
    note text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT dividends_amount_minor_check CHECK ((amount_minor > 0))
);


ALTER TABLE public.dividends OWNER TO monikey;

--
-- Name: external_api_usage; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.external_api_usage (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider text NOT NULL,
    period text NOT NULL,
    operation text NOT NULL,
    call_count integer DEFAULT 0 NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.external_api_usage OWNER TO monikey;

--
-- Name: financial_accounts; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.financial_accounts (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    name text NOT NULL,
    institution text,
    account_type public.account_type NOT NULL,
    classification public.account_classification NOT NULL,
    currency_code character(3) DEFAULT 'PHP'::bpchar NOT NULL,
    opening_balance_minor bigint DEFAULT 0 NOT NULL,
    current_balance_minor bigint DEFAULT 0 NOT NULL,
    last_four text,
    sync_status text DEFAULT 'manual'::text NOT NULL,
    manual boolean DEFAULT true NOT NULL,
    version integer DEFAULT 0 NOT NULL,
    archived_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT financial_accounts_asset_non_negative_chk CHECK (((classification <> 'asset'::public.account_classification) OR ((current_balance_minor >= 0) AND (opening_balance_minor >= 0)))),
    CONSTRAINT financial_accounts_card_liability_chk CHECK (((account_type = 'credit_card'::public.account_type) = (classification = 'liability'::public.account_classification)))
);


ALTER TABLE public.financial_accounts OWNER TO monikey;

--
-- Name: fx_rate_snapshots; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.fx_rate_snapshots (
    base_currency character(3) NOT NULL,
    quote_currency character(3) NOT NULL,
    rate numeric(20,10) NOT NULL,
    provider character varying(50) NOT NULL,
    rate_date date NOT NULL,
    fetched_at timestamp(6) with time zone NOT NULL,
    created_at timestamp(6) with time zone DEFAULT now() NOT NULL,
    CONSTRAINT check_currencies_valid CHECK (((base_currency ~ '^[A-Z]{3}$'::text) AND (quote_currency ~ '^[A-Z]{3}$'::text))),
    CONSTRAINT check_rate_positive CHECK ((rate > (0)::numeric))
);


ALTER TABLE public.fx_rate_snapshots OWNER TO monikey;

--
-- Name: goal_contributions; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.goal_contributions (
    id uuid NOT NULL,
    goal_id uuid NOT NULL,
    transaction_id uuid NOT NULL,
    source_account_id uuid NOT NULL,
    amount_minor bigint NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.goal_contributions OWNER TO monikey;

--
-- Name: goals; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.goals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name text NOT NULL,
    target_minor bigint NOT NULL,
    current_minor bigint DEFAULT 0 NOT NULL,
    currency_code character(3) DEFAULT 'PHP'::bpchar NOT NULL,
    target_date date NOT NULL,
    completed_date date,
    monthly_contribution_minor bigint,
    status text DEFAULT 'active'::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.goals OWNER TO monikey;

--
-- Name: import_batches; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.import_batches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    import_source_id uuid,
    import_source_type text NOT NULL,
    status text DEFAULT 'reviewing'::text NOT NULL,
    matched_account_id uuid,
    total_count integer DEFAULT 0 NOT NULL,
    committed_count integer DEFAULT 0 NOT NULL,
    error_count integer DEFAULT 0 NOT NULL,
    error_message text,
    created_at timestamp(6) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT now() NOT NULL,
    committed_at timestamp(6) with time zone
);


ALTER TABLE public.import_batches OWNER TO monikey;

--
-- Name: imported_transactions; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.imported_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    import_batch_id uuid NOT NULL,
    dedup_key text NOT NULL,
    provider text NOT NULL,
    provider_transaction_id text,
    occurred_on date NOT NULL,
    title text NOT NULL,
    description text,
    amount_minor bigint NOT NULL,
    currency_code character(3) DEFAULT 'PHP'::bpchar NOT NULL,
    merchant_name text,
    status text DEFAULT 'pending_review'::text NOT NULL,
    validation_errors text[] DEFAULT '{}'::text[] NOT NULL,
    created_at timestamp(6) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.imported_transactions OWNER TO monikey;

--
-- Name: instruments; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.instruments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    ticker text NOT NULL,
    name text NOT NULL,
    asset_class text NOT NULL,
    sector text NOT NULL,
    currency_code character(3) DEFAULT 'PHP'::bpchar NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.instruments OWNER TO monikey;

--
-- Name: investment_trades; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.investment_trades (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    instrument_id uuid NOT NULL,
    type public.investment_trade_type NOT NULL,
    units numeric(30,10) NOT NULL,
    price_minor bigint NOT NULL,
    occurred_on date NOT NULL,
    cash_account_id uuid,
    note text,
    idempotency_key text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT investment_trades_price_minor_check CHECK ((price_minor > 0)),
    CONSTRAINT investment_trades_units_check CHECK ((units > (0)::numeric))
);


ALTER TABLE public.investment_trades OWNER TO monikey;

--
-- Name: notification_outbox; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.notification_outbox (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    kind text NOT NULL,
    dedupe_key text NOT NULL,
    payload jsonb NOT NULL,
    status public.notification_status DEFAULT 'pending'::public.notification_status NOT NULL,
    available_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    sent_at timestamp(6) with time zone,
    attempt_count integer DEFAULT 0 NOT NULL,
    last_error text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.notification_outbox OWNER TO monikey;

--
-- Name: plaid_items; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.plaid_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    item_id text NOT NULL,
    institution_name text,
    account_ids text[] DEFAULT '{}'::text[] NOT NULL,
    encrypted_access_token text NOT NULL,
    last_synced_at timestamp with time zone,
    status text DEFAULT 'active'::text NOT NULL,
    error_message text,
    created_at timestamp(6) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.plaid_items OWNER TO monikey;

--
-- Name: plaid_link_tokens; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.plaid_link_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    link_token text NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    created_at timestamp(6) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.plaid_link_tokens OWNER TO monikey;

--
-- Name: postings; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.postings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    imported_transaction_id uuid NOT NULL,
    transaction_id uuid NOT NULL,
    created_at timestamp(6) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.postings OWNER TO monikey;

--
-- Name: quote_snapshots; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.quote_snapshots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    instrument_id uuid NOT NULL,
    source text NOT NULL,
    price_minor bigint NOT NULL,
    currency_code character(3) DEFAULT 'PHP'::bpchar NOT NULL,
    fetched_at timestamp(6) with time zone NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT quote_snapshots_price_minor_check CHECK ((price_minor > 0))
);


ALTER TABLE public.quote_snapshots OWNER TO monikey;

--
-- Name: receipts; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.receipts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    storage_key text NOT NULL,
    original_filename text NOT NULL,
    mime_type text NOT NULL,
    size_bytes bigint NOT NULL,
    sha256 character(64) NOT NULL,
    status text DEFAULT 'uploaded'::text NOT NULL,
    ocr_provider text,
    ocr_text text,
    parsed_payload jsonb,
    transaction_id uuid,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.receipts OWNER TO monikey;

--
-- Name: recurring_items; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.recurring_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    merchant text NOT NULL,
    amount_minor bigint NOT NULL,
    frequency public.recurring_frequency NOT NULL,
    next_due_date date NOT NULL,
    account_id uuid NOT NULL,
    category_id uuid NOT NULL,
    autopay boolean DEFAULT false NOT NULL,
    status public.recurring_status DEFAULT 'active'::public.recurring_status NOT NULL,
    last_paid_date date,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT recurring_items_amount_minor_check CHECK ((amount_minor > 0))
);


ALTER TABLE public.recurring_items OWNER TO monikey;

--
-- Name: transaction_balance_effects; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.transaction_balance_effects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    transaction_id uuid NOT NULL,
    account_id uuid NOT NULL,
    role public.balance_effect_role NOT NULL,
    delta_minor bigint NOT NULL,
    balance_after_minor bigint NOT NULL,
    created_at timestamp(6) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.transaction_balance_effects OWNER TO monikey;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    type public.transaction_type NOT NULL,
    title text NOT NULL,
    category_id uuid,
    goal_id uuid,
    from_account_id uuid,
    to_account_id uuid,
    occurred_on date NOT NULL,
    occurred_time time without time zone,
    amount_minor bigint NOT NULL,
    fee_minor bigint DEFAULT 0 NOT NULL,
    currency_code character(3) DEFAULT 'PHP'::bpchar NOT NULL,
    source public.transaction_source NOT NULL,
    status public.transaction_status NOT NULL,
    note text,
    idempotency_key text,
    reversed_transaction_id uuid,
    created_at timestamp(6) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.transactions OWNER TO monikey;

--
-- Name: user_preferences; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.user_preferences (
    user_id uuid NOT NULL,
    bill_due_reminders boolean DEFAULT true NOT NULL,
    budget_near_limit_warnings boolean DEFAULT true NOT NULL,
    weekly_summary_email boolean DEFAULT false NOT NULL,
    hide_cents boolean DEFAULT false NOT NULL,
    external_ai_enabled boolean DEFAULT false NOT NULL,
    external_ocr_enabled boolean DEFAULT false NOT NULL,
    detailed_ai_context_enabled boolean DEFAULT false NOT NULL,
    created_at timestamp(6) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.user_preferences OWNER TO monikey;

--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.user_sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    last_seen_at timestamp(6) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(6) with time zone DEFAULT now() NOT NULL,
    user_agent text
);


ALTER TABLE public.user_sessions OWNER TO monikey;

--
-- Name: users; Type: TABLE; Schema: public; Owner: monikey
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    display_name text NOT NULL,
    timezone text DEFAULT 'Asia/Manila'::text NOT NULL,
    base_currency character(3) DEFAULT 'PHP'::bpchar NOT NULL,
    created_at timestamp(6) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.users OWNER TO monikey;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
6bd8ec36-b01b-4415-b35e-8c8f3b519660	2d3f9c6be51dc866bc35c6010c16e8ffb04be2a26e5ee4380e11e07750063c88	2026-09-01 07:42:19.086161+00	20260831000000_init	\N	\N	2026-09-01 07:42:18.912213+00	1
f97b6753-34de-48d7-a195-249f426bf18d	a7710ee383824806bf9a12365901645c5718fc027406ebb73892e694dd7e8234	2026-09-01 07:42:20.056165+00	20260901030000_receipts	\N	\N	2026-09-01 07:42:19.937606+00	1
644e43ed-2cf8-4672-95a8-8fc4a6d3c203	b7a59d98881f785f7107831a49a836182aa78f18a4e4e6058d5aa32d4249376f	2026-09-01 07:42:19.114716+00	20260831073737_session_expiry_index	\N	\N	2026-09-01 07:42:19.089967+00	1
1784349c-0add-47dd-90c2-58aed5b9d3f4	92dd1c8b439e2e0443e799e90ac79aabe0d9e9204e30a13782b4c89a9ec6a1e1	2026-09-01 07:42:19.24445+00	20260831180000_phase3_ledger_transactions	\N	\N	2026-09-01 07:42:19.118145+00	1
42037778-59ba-4982-8890-c34432753430	4c8eb694efb091566d9e5fbca5418f3035229633de3ec18b28c17d16148b5b42	2026-09-01 07:42:19.291662+00	20260831210000_goal_contributions	\N	\N	2026-09-01 07:42:19.247643+00	1
cc30f05b-5283-40bb-99fc-5b5407cf70b2	174dc6ed08bf967e79df1c8c23705ac826c368568db57bb15109d312d29235bd	2026-09-01 07:42:20.279176+00	20260901040000_phase11_imports_plaid	\N	\N	2026-09-01 07:42:20.059271+00	1
85a10b06-762f-4655-bf8f-e625f86eec4c	28ae4b5dbfed0d429192b8fc448e70e858a697ecc9396804bf626e6666169811	2026-09-01 07:42:19.366081+00	20260831220000_budgets	\N	\N	2026-09-01 07:42:19.295026+00	1
32f609d0-6847-4b5e-9e58-0f215ce24884	2bd97c015125db5bae2c3e115d7de857685943da7f11ad3afd825b4ee02f80b1	2026-09-01 07:42:19.427776+00	20260831230000_recurring_items	\N	\N	2026-09-01 07:42:19.369579+00	1
78de6f28-e870-4f80-bc12-4c433b1f644b	aa8968aa44ed84ca120bc873c96e6d3f35541721113f632978352c4a85df0371	2026-09-01 07:42:19.49183+00	20260831231500_notification_outbox	\N	\N	2026-09-01 07:42:19.431024+00	1
cc54d101-110e-4689-8854-58b88af4237a	a3ec4cabfdc1189a34b7798458b91259936a8c2edb94d60ed62bc71f3f27405a	2026-09-01 07:42:20.30248+00	20260901042000_phase11_defect5_unique_global_dedup	\N	\N	2026-09-01 07:42:20.282937+00	1
892493e5-a953-4ac7-9109-7eeb264f5d0b	8d71af1f4a6d6e46a437eca28d350a5ddea0ddc4fd728671557bf6ed1fbb1431	2026-09-01 07:42:19.632638+00	20260831233000_investments	\N	\N	2026-09-01 07:42:19.495539+00	1
c5917954-0f90-442a-8e60-48ffca153e72	cd1fb467a44277ef5944c49f5d3e07f3a76edd5d2afbd372db8e8970853d9d92	2026-09-01 07:42:19.685068+00	20260831234500_quote_snapshots	\N	\N	2026-09-01 07:42:19.636251+00	1
a11f0716-19b5-4395-bca2-20933a1e5f28	e6c767585acb5534a11de5a0d365cc9610edd9cca91249382ae9b3302b603192	2026-09-01 07:42:19.789763+00	20260831240000_align_transaction_enums	\N	\N	2026-09-01 07:42:19.688523+00	1
2bb357b1-92c6-4afd-96a6-68d7b2ab9fb1	29dff4694e97ced6b739cbb4eb9cd0ebd78c8dbfcfc992141a6fbc30b915cf0c	2026-09-01 07:42:19.834553+00	20260901000000_external_api_usage	\N	\N	2026-09-01 07:42:19.795249+00	1
3a9a07b1-4394-412e-a613-62b365004328	728416fc64594eef412df9a9754eff92eb6ad7cd399fc0a6d6934d88d705af53	2026-09-01 07:42:19.868985+00	20260901010000_daily_finance_snapshots	\N	\N	2026-09-01 07:42:19.837986+00	1
e60f6d01-29e0-4009-8454-8d8bed5a4547	8fc58818630c643a23726a0969b483740adcc7c415bd8f9fa822cf85215deab3	2026-09-01 07:42:19.93239+00	20260901020000_fx_rate_snapshots	\N	\N	2026-09-01 07:42:19.872368+00	1
\.


--
-- Data for Name: budget_allocations; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.budget_allocations (id, budget_period_id, category_id, allocated_minor, created_at, updated_at) FROM stdin;
e98b1845-4aae-46e2-962a-23653eb7f28e	c4bc31a5-e746-4e69-913d-b7efc2ec274f	98914c49-62d7-4f1e-a186-ab0ebcc70172	2000	2026-09-01 07:42:27.164+00	2026-09-01 07:42:27.164+00
a5815323-eee5-4020-ac65-91db5cc92cd7	807ca209-515c-4835-93f6-95d9b12c8b76	2ee8ee87-7f75-4c53-8163-ea9a46844dcc	900	2026-09-01 07:42:27.477+00	2026-09-01 07:42:27.489+00
d45454ca-2db9-4baf-9db6-287e49b786cc	b198cc76-fb48-48b2-b42d-64f37de23084	661009bb-7ad9-4dbd-b0f9-446424b2daf2	1000	2026-09-01 07:42:27.686+00	2026-09-01 07:42:27.686+00
1144d377-f44f-42f8-9e2c-4dc1f6f426fa	5551b457-be7f-4d19-a585-52dba5adb524	6d1e2bd3-7ae7-457f-9393-ff15b89cdf14	100000	2026-09-01 07:42:29.833+00	2026-09-01 07:42:29.833+00
08e98921-e892-4651-898d-634310b63c30	5551b457-be7f-4d19-a585-52dba5adb524	75b2324d-2d49-43b0-8d2e-d4a15db870d8	50000	2026-09-01 07:42:29.846+00	2026-09-01 07:42:29.846+00
\.


--
-- Data for Name: budget_periods; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.budget_periods (id, user_id, period_start, period_end, income_pool_minor, created_at, updated_at) FROM stdin;
c4bc31a5-e746-4e69-913d-b7efc2ec274f	c459dd63-add4-42e6-9da4-2a2125730419	2026-09-01	2026-09-30	5000	2026-09-01 07:42:27.152+00	2026-09-01 07:42:27.152+00
807ca209-515c-4835-93f6-95d9b12c8b76	32949b3a-9b25-40c2-8979-d3b44a693d5e	2026-09-01	2026-09-30	0	2026-09-01 07:42:27.47+00	2026-09-01 07:42:27.47+00
b198cc76-fb48-48b2-b42d-64f37de23084	7509999e-3327-4d5d-93ed-c2ee5eb5db98	2026-09-01	2026-09-30	0	2026-09-01 07:42:27.675+00	2026-09-01 07:42:27.675+00
5551b457-be7f-4d19-a585-52dba5adb524	6dea893a-a41c-4d68-8c8a-37fa9f3baaee	2026-09-01	2026-09-30	0	2026-09-01 07:42:29.821+00	2026-09-01 07:42:29.821+00
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.categories (id, user_id, name, color, budgetable, allows_income, allows_expense, archived_at, created_at, updated_at) FROM stdin;
98914c49-62d7-4f1e-a186-ab0ebcc70172	c459dd63-add4-42e6-9da4-2a2125730419	Groceries	#111	t	f	t	\N	2026-09-01 07:42:27.109+00	2026-09-01 07:42:27.109+00
db3416c2-c1c4-49fb-9d0a-2e476783b543	c459dd63-add4-42e6-9da4-2a2125730419	Other	#222	t	f	t	\N	2026-09-01 07:42:27.122+00	2026-09-01 07:42:27.122+00
a665b674-03d4-40bb-9390-accf047de19d	c0c99378-34f9-415e-92d1-65568519d3cb	Food	#111	t	f	t	\N	2026-09-01 07:42:27.138+00	2026-09-01 07:42:27.138+00
196c197e-afc4-4f8d-9dc5-be83f2f7be61	b9faca84-eff8-413b-a84a-fff402b161ef	Food	#111	t	f	t	\N	2026-09-01 07:42:27.324+00	2026-09-01 07:42:27.324+00
2ee8ee87-7f75-4c53-8163-ea9a46844dcc	32949b3a-9b25-40c2-8979-d3b44a693d5e	Transport	#333	t	f	t	\N	2026-09-01 07:42:27.463+00	2026-09-01 07:42:27.463+00
01d406be-e578-413f-8f9e-69849e2bfd2e	181d14b5-5a57-4432-b64c-629b94cc5b85	Food	#111	t	f	t	\N	2026-09-01 07:42:27.47+00	2026-09-01 07:42:27.47+00
661009bb-7ad9-4dbd-b0f9-446424b2daf2	7509999e-3327-4d5d-93ed-c2ee5eb5db98	Utilities	#444	t	f	t	\N	2026-09-01 07:42:27.667+00	2026-09-01 07:42:27.667+00
bc77081d-5450-4cc2-a172-b6884e8c195a	e641b12c-d43d-4196-b0e6-f0df1b87acc1	Food	#111	t	f	t	\N	2026-09-01 07:42:27.714+00	2026-09-01 07:42:27.714+00
6d1e2bd3-7ae7-457f-9393-ff15b89cdf14	6dea893a-a41c-4d68-8c8a-37fa9f3baaee	Food	#000	t	f	t	\N	2026-09-01 07:42:29.803+00	2026-09-01 07:42:29.803+00
75b2324d-2d49-43b0-8d2e-d4a15db870d8	6dea893a-a41c-4d68-8c8a-37fa9f3baaee	Transport	#000	t	f	t	\N	2026-09-01 07:42:29.814+00	2026-09-01 07:42:29.814+00
\.


--
-- Data for Name: credit_card_details; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.credit_card_details (account_id, network, credit_limit_minor, due_day, minimum_payment_minor, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: daily_finance_snapshots; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.daily_finance_snapshots (user_id, snapshot_date, asset_total_minor, liability_total_minor, net_worth_minor, card_debt_minor, base_currency, generated_at) FROM stdin;
88440775-16b8-4a67-8555-420bfb03ced3	2026-09-30	520000	0	520000	0	PHP	2026-09-01 07:42:27.238+00
aa587028-2f15-4d8b-b576-7d1c9223ad1d	2026-09-01	100000	0	100000	0	PHP	2026-09-01 07:42:28.087+00
aa587028-2f15-4d8b-b576-7d1c9223ad1d	2026-09-02	150000	0	150000	0	PHP	2026-09-01 07:42:28.095+00
aa587028-2f15-4d8b-b576-7d1c9223ad1d	2026-09-03	120000	0	120000	0	PHP	2026-09-01 07:42:28.151+00
ddc2ad9c-44b9-4c57-b75d-ee748cdbf619	2026-09-30	100000	0	100000	0	PHP	2026-09-01 07:42:29.35+00
\.


--
-- Data for Name: dividends; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.dividends (id, user_id, instrument_id, amount_minor, occurred_on, note, created_at) FROM stdin;
\.


--
-- Data for Name: external_api_usage; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.external_api_usage (id, provider, period, operation, call_count, updated_at) FROM stdin;
ebdaa459-b252-4043-9ef6-4bae7ee78f4b	test_provider_zero	2026-08-31	test_op	0	2026-09-01 07:42:29.337024+00
18abbe6c-bccf-479a-a434-1781b65f9d8f	test_provider_max1	2026-08-31	test_op	1	2026-09-01 07:42:29.440562+00
a49961f3-484b-4522-9c5a-db42d82963d3	ocrspace	2026-09-01	extract	450	2026-09-01 07:42:38.696+00
\.


--
-- Data for Name: financial_accounts; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.financial_accounts (id, user_id, name, institution, account_type, classification, currency_code, opening_balance_minor, current_balance_minor, last_four, sync_status, manual, version, archived_at, created_at, updated_at) FROM stdin;
ac1769af-84c4-4ba8-b9da-9ead3ad050fe	c0c99378-34f9-415e-92d1-65568519d3cb	Test cash	\N	checking	asset	PHP	100000	100000	\N	manual	t	0	\N	2026-09-01 07:42:27.119+00	2026-09-01 07:42:27.119+00
c9d6e5bb-53f6-4806-8024-a1b6e19ec604	c459dd63-add4-42e6-9da4-2a2125730419	Test cash	\N	checking	asset	PHP	10000	10000	\N	manual	t	0	\N	2026-09-01 07:42:27.13+00	2026-09-01 07:42:27.13+00
cbb768e9-95c1-4669-9fca-aed3b11a83d9	e9de0939-7fa9-4618-b6f2-380f180e125e	Test cash	\N	checking	asset	PHP	5000	4500	\N	manual	t	0	\N	2026-09-01 07:42:27.109+00	2026-09-01 07:42:27.187+00
b43a90e0-d8b2-4c87-a7e1-77348528d998	e641b12c-d43d-4196-b0e6-f0df1b87acc1	Test cash	\N	checking	asset	PHP	100000	100000	\N	manual	t	0	\N	2026-09-01 07:42:27.691+00	2026-09-01 07:42:27.691+00
eef01f47-b88f-4128-8d30-51b0977a18e0	b9faca84-eff8-413b-a84a-fff402b161ef	Test cash	\N	checking	asset	PHP	100000	100000	\N	manual	t	0	\N	2026-09-01 07:42:27.308+00	2026-09-01 07:42:27.308+00
0b31b94f-a2ae-4aca-a169-16188c9eb22b	547b3c42-5d09-486a-8a86-cb626bc32183	Test cash	\N	checking	asset	PHP	5000	4000	\N	manual	t	0	\N	2026-09-01 07:42:27.348+00	2026-09-01 07:42:27.403+00
6fe610e6-580a-44d0-aac8-762858f2d5e8	d48d3f97-0223-44cb-8c8c-6ceec75a083e	Test cash	\N	checking	asset	PHP	5000	4700	\N	manual	t	0	\N	2026-09-01 07:42:27.804+00	2026-09-01 07:42:27.893+00
2ceb3f35-ba3c-400b-9f66-7554e52221ca	c16888ea-eeeb-4bba-9c45-606b4056aa78	Test Checking	\N	checking	asset	PHP	100000	100000	\N	manual	t	0	\N	2026-09-01 07:42:27.986+00	2026-09-01 07:42:27.986+00
cdc3a9a2-aff9-4cda-8c6d-57262e68e78b	181d14b5-5a57-4432-b64c-629b94cc5b85	Test cash	\N	checking	asset	PHP	100000	100000	\N	manual	t	0	\N	2026-09-01 07:42:27.461+00	2026-09-01 07:42:27.461+00
587998e9-3e7e-435a-8270-8821f470e7c9	762339a8-2887-4f3c-bbc0-5117703433ce	Test cash	\N	checking	asset	PHP	5000	4500	\N	manual	t	0	\N	2026-09-01 07:42:28.146+00	2026-09-01 07:42:28.298+00
831e25e1-d2f0-4429-9360-c07cfcb3347f	c67f8063-e14c-4879-8211-60cb93097b78	Test Checking	\N	checking	asset	PHP	100000	100000	\N	manual	t	0	\N	2026-09-01 07:42:28.944+00	2026-09-01 07:42:28.944+00
6efd8d3d-3089-4f80-bfc9-fb26964ea924	07e727a7-d620-45c6-990a-0a9dc4da7e88	Test Account	\N	checking	asset	PHP	500000	350000	\N	manual	t	0	\N	2026-09-01 07:42:29.628+00	2026-09-01 07:42:29.804+00
a2286807-9141-4fe4-a013-ce5bf976c925	245edc36-4630-4c3f-a28b-c5933bf8f0f7	Test Account	\N	checking	asset	PHP	100000	100000	\N	manual	t	0	\N	2026-09-01 07:42:29.07+00	2026-09-01 07:42:29.07+00
de94f393-683a-471f-a628-1be9ccb198a0	2ed833e4-a957-47cb-bb83-45e53cf1300e	Test Account	\N	checking	asset	PHP	100000	100000	\N	manual	t	0	\N	2026-09-01 07:42:29.32+00	2026-09-01 07:42:29.32+00
57b3a0a6-6b21-4f11-8041-403e49223537	6dea893a-a41c-4d68-8c8a-37fa9f3baaee	Test Account	\N	checking	asset	PHP	500000	400000	\N	manual	t	0	\N	2026-09-01 07:42:29.778+00	2026-09-01 07:42:29.953+00
556367a5-157d-4908-9d6d-87c59a3662bc	54642217-2a01-4151-9137-e2f05b7134c3	Test Account	\N	checking	asset	PHP	500000	400000	\N	manual	t	0	\N	2026-09-01 07:42:29.92+00	2026-09-01 07:42:30.12+00
\.


--
-- Data for Name: fx_rate_snapshots; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.fx_rate_snapshots (base_currency, quote_currency, rate, provider, rate_date, fetched_at, created_at) FROM stdin;
\.


--
-- Data for Name: goal_contributions; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.goal_contributions (id, goal_id, transaction_id, source_account_id, amount_minor, created_at) FROM stdin;
2cc04873-f703-4a65-9b4e-6806d60d5cc3	a9341a29-508d-4881-b96a-9118284496da	5726cbbd-f40c-4890-be54-fdcada653cde	cbb768e9-95c1-4669-9fca-aed3b11a83d9	500	2026-09-01 07:42:27.198+00
72ebbe87-ad32-4d32-8801-f04e00c82350	1b5ccb3b-a4d8-4083-865c-fa82e073f418	9699f04e-390c-409b-b649-5ec9572e7c98	0b31b94f-a2ae-4aca-a169-16188c9eb22b	1000	2026-09-01 07:42:27.411+00
ad616fd7-a559-4a32-9301-a69b0d7e0464	025b2436-166f-4d10-9bbd-86663d7b2fbc	8611e7fa-61c4-41a8-a7a2-68760c6627cf	6fe610e6-580a-44d0-aac8-762858f2d5e8	300	2026-09-01 07:42:27.91+00
1bda3c1f-cd71-461f-b9e9-26641223b31c	57c364ee-8c06-4abd-b379-89998454eabe	f3a6b745-e3f4-48e0-bcc1-9c42fa44d7b8	587998e9-3e7e-435a-8270-8821f470e7c9	500	2026-09-01 07:42:28.345+00
\.


--
-- Data for Name: goals; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.goals (id, user_id, name, target_minor, current_minor, currency_code, target_date, completed_date, monthly_contribution_minor, status, active, created_at, updated_at) FROM stdin;
a9341a29-508d-4881-b96a-9118284496da	e9de0939-7fa9-4618-b6f2-380f180e125e	Emergency fund	2000	500	PHP	2027-01-01	\N	\N	active	t	2026-09-01 07:42:27.126+00	2026-09-01 07:42:27.138549+00
1b5ccb3b-a4d8-4083-865c-fa82e073f418	547b3c42-5d09-486a-8a86-cb626bc32183	Emergency fund	1000	1000	PHP	2027-01-01	\N	\N	active	t	2026-09-01 07:42:27.368+00	2026-09-01 07:42:27.374734+00
025b2436-166f-4d10-9bbd-86663d7b2fbc	d48d3f97-0223-44cb-8c8c-6ceec75a083e	Emergency fund	2000	300	PHP	2027-01-01	\N	\N	active	t	2026-09-01 07:42:27.829+00	2026-09-01 07:42:27.841222+00
57c364ee-8c06-4abd-b379-89998454eabe	762339a8-2887-4f3c-bbc0-5117703433ce	Emergency fund	800	500	PHP	2027-01-01	\N	\N	active	t	2026-09-01 07:42:28.178+00	2026-09-01 07:42:28.195517+00
\.


--
-- Data for Name: import_batches; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.import_batches (id, user_id, import_source_id, import_source_type, status, matched_account_id, total_count, committed_count, error_count, error_message, created_at, updated_at, committed_at) FROM stdin;
6e3ba0da-8a11-4be2-9d9a-8b95c0cb94cc	c16888ea-eeeb-4bba-9c45-606b4056aa78	\N	csv_manual	reviewing	\N	0	0	0	\N	2026-09-01 07:42:28.19+00	2026-09-01 07:42:28.19+00	\N
c9014af6-1658-40f2-a7a9-72ad5cb4e157	c67f8063-e14c-4879-8211-60cb93097b78	\N	csv_manual	reviewing	\N	1	0	0	\N	2026-09-01 07:42:28.964+00	2026-09-01 07:42:29.028549+00	\N
309a2d96-cb23-4857-a8a6-9e6b7e713b7a	245edc36-4630-4c3f-a28b-c5933bf8f0f7	\N	csv_manual	reviewing	\N	1	0	0	\N	2026-09-01 07:42:29.093+00	2026-09-01 07:42:29.170344+00	\N
1a7b6124-7470-4939-a495-450f6d5ec165	2ed833e4-a957-47cb-bb83-45e53cf1300e	\N	csv_manual	reviewing	\N	0	0	0	\N	2026-09-01 07:42:29.392+00	2026-09-01 07:42:29.392+00	\N
324b4a53-bd88-44c7-b2c2-c261a58c6c27	2ed833e4-a957-47cb-bb83-45e53cf1300e	\N	csv_manual	reviewing	\N	1	0	0	\N	2026-09-01 07:42:29.35+00	2026-09-01 07:42:29.506236+00	\N
226102fa-2c2b-4020-80e7-11f65fb1bc81	07e727a7-d620-45c6-990a-0a9dc4da7e88	\N	csv_manual	committed	\N	1	1	0	\N	2026-09-01 07:42:29.648+00	2026-09-01 07:42:29.847836+00	2026-09-01 07:42:29.845+00
e2da4191-c293-4c12-bcbf-302e3422b354	54642217-2a01-4151-9137-e2f05b7134c3	\N	csv_manual	committed	\N	1	1	0	\N	2026-09-01 07:42:29.951+00	2026-09-01 07:42:30.197812+00	2026-09-01 07:42:30.19+00
8ea1b845-c77b-4983-8bcf-63d177c51638	5b97f226-a3d8-45bd-b337-ef6a16f57bbf	\N	csv_manual	reviewing	\N	0	0	0	\N	2026-09-01 07:42:30.439+00	2026-09-01 07:42:30.439+00	\N
3f447068-57e8-44d0-b11f-19d86b992563	e7ab63fc-78a0-4cb2-923d-a2c624b47acd	\N	csv_manual	reviewing	\N	0	0	0	\N	2026-09-01 07:42:30.51+00	2026-09-01 07:42:30.51+00	\N
\.


--
-- Data for Name: imported_transactions; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.imported_transactions (id, import_batch_id, dedup_key, provider, provider_transaction_id, occurred_on, title, description, amount_minor, currency_code, merchant_name, status, validation_errors, created_at) FROM stdin;
49a64478-20f4-4187-a9e7-b0f297392d2f	c9014af6-1658-40f2-a7a9-72ad5cb4e157	test_1788248547525_qaks1a_csv_row_1	csv	\N	2026-09-01	Coffee Shop	\N	15050	PHP	Cafe Noir	pending_review	{}	2026-09-01 07:42:29.001+00
c1d7055d-4a78-4209-973e-6fa148f85815	309a2d96-cb23-4857-a8a6-9e6b7e713b7a	test_1788248547525_qaks1a_same_dedup_key	csv	\N	2026-09-01	Transaction 1	\N	50000	PHP	\N	pending_review	{}	2026-09-01 07:42:29.144+00
c275db89-01d9-4a6c-86d9-69f25a0420d0	324b4a53-bd88-44c7-b2c2-c261a58c6c27	test_1788248547525_qaks1a_global_dedup_key	csv	\N	2026-09-01	Transaction	\N	50000	PHP	\N	pending_review	{}	2026-09-01 07:42:29.464+00
28e2fb38-5de7-46d5-b563-af2c1890e90a	226102fa-2c2b-4020-80e7-11f65fb1bc81	test_1788248547525_qaks1a_expense_1	csv	\N	2026-09-01	Grocery Store	\N	150000	PHP	\N	validated	{}	2026-09-01 07:42:29.679+00
31a3e5ce-2e83-4a57-82b9-52549df08e06	e2da4191-c293-4c12-bcbf-302e3422b354	test_1788248547525_qaks1a_expense_idempotent	csv	\N	2026-09-01	Expense	\N	100000	PHP	\N	validated	{}	2026-09-01 07:42:29.99+00
\.


--
-- Data for Name: instruments; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.instruments (id, user_id, ticker, name, asset_class, sector, currency_code, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: investment_trades; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.investment_trades (id, user_id, instrument_id, type, units, price_minor, occurred_on, cash_account_id, note, idempotency_key, created_at) FROM stdin;
\.


--
-- Data for Name: notification_outbox; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.notification_outbox (id, user_id, kind, dedupe_key, payload, status, available_at, sent_at, attempt_count, last_error, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plaid_items; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.plaid_items (id, user_id, item_id, institution_name, account_ids, encrypted_access_token, last_synced_at, status, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plaid_link_tokens; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.plaid_link_tokens (id, user_id, link_token, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: postings; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.postings (id, imported_transaction_id, transaction_id, created_at) FROM stdin;
e36817fe-450c-471f-b12b-b1afcd9ae189	28e2fb38-5de7-46d5-b563-af2c1890e90a	7d7f6b73-e7f4-48ea-b80f-be3ebadbefc6	2026-09-01 07:42:29.817+00
4763d993-3d55-41f4-819e-b4d52b62739d	31a3e5ce-2e83-4a57-82b9-52549df08e06	2f76a224-2578-4207-baa0-c3cf98e43c08	2026-09-01 07:42:30.143+00
\.


--
-- Data for Name: quote_snapshots; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.quote_snapshots (id, instrument_id, source, price_minor, currency_code, fetched_at, created_at) FROM stdin;
\.


--
-- Data for Name: receipts; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.receipts (id, user_id, storage_key, original_filename, mime_type, size_bytes, sha256, status, ocr_provider, ocr_text, parsed_payload, transaction_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: recurring_items; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.recurring_items (id, user_id, merchant, amount_minor, frequency, next_due_date, account_id, category_id, autopay, status, last_paid_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: transaction_balance_effects; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.transaction_balance_effects (id, transaction_id, account_id, role, delta_minor, balance_after_minor, created_at) FROM stdin;
e01ef538-3b17-4679-b7f0-ffc9a9271f55	5726cbbd-f40c-4890-be54-fdcada653cde	cbb768e9-95c1-4669-9fca-aed3b11a83d9	source	-500	4500	2026-09-01 07:42:27.182+00
2bac5bba-65d6-43b2-bdaa-c36ea1900de4	9699f04e-390c-409b-b649-5ec9572e7c98	0b31b94f-a2ae-4aca-a169-16188c9eb22b	source	-1000	4000	2026-09-01 07:42:27.399+00
a82025dd-bded-470f-932e-b484821694ec	8611e7fa-61c4-41a8-a7a2-68760c6627cf	6fe610e6-580a-44d0-aac8-762858f2d5e8	source	-300	4700	2026-09-01 07:42:27.884+00
8ae47e7b-aaec-4bac-9262-f01c8b59aa66	f3a6b745-e3f4-48e0-bcc1-9c42fa44d7b8	587998e9-3e7e-435a-8270-8821f470e7c9	source	-500	4500	2026-09-01 07:42:28.283+00
bdf7e107-e59e-4adf-b3b8-e9b6883d613d	7d7f6b73-e7f4-48ea-b80f-be3ebadbefc6	6efd8d3d-3089-4f80-bfc9-fb26964ea924	expense	-150000	350000	2026-09-01 07:42:29.79+00
323c3825-9c69-4df0-9d6e-7b6848811e41	384f3462-c1df-426b-b50d-5b56035111db	57b3a0a6-6b21-4f11-8041-403e49223537	expense	-60000	440000	2026-09-01 07:42:29.879+00
a408aca5-8de0-4376-9bae-5e552311c97f	b1b39522-4445-4f73-8d05-5a52543d0056	57b3a0a6-6b21-4f11-8041-403e49223537	expense	-40000	400000	2026-09-01 07:42:29.941+00
e3c276ed-e275-4872-8995-23b9a56d3923	2f76a224-2578-4207-baa0-c3cf98e43c08	556367a5-157d-4908-9d6d-87c59a3662bc	expense	-100000	400000	2026-09-01 07:42:30.109+00
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.transactions (id, user_id, type, title, category_id, goal_id, from_account_id, to_account_id, occurred_on, occurred_time, amount_minor, fee_minor, currency_code, source, status, note, idempotency_key, reversed_transaction_id, created_at, updated_at) FROM stdin;
5d834e80-73d8-478f-8f03-2f109d340630	c0c99378-34f9-415e-92d1-65568519d3cb	expense	Test expense	a665b674-03d4-40bb-9390-accf047de19d	\N	ac1769af-84c4-4ba8-b9da-9ead3ad050fe	\N	2026-08-15	\N	50000	0	PHP	manual	cleared	\N	\N	\N	2026-09-01 07:42:27.156+00	2026-09-01 07:42:27.156+00
5726cbbd-f40c-4890-be54-fdcada653cde	e9de0939-7fa9-4618-b6f2-380f180e125e	transfer	Goal funding	\N	a9341a29-508d-4881-b96a-9118284496da	cbb768e9-95c1-4669-9fca-aed3b11a83d9	\N	2026-09-01	\N	500	0	PHP	manual	cleared	\N	goal-fund-happy	\N	2026-09-01 07:42:27.174+00	2026-09-01 07:42:27.174+00
2d72ff8f-73ac-4893-9050-fb19f9574c4a	c459dd63-add4-42e6-9da4-2a2125730419	expense	Wet market	98914c49-62d7-4f1e-a186-ab0ebcc70172	\N	c9d6e5bb-53f6-4806-8024-a1b6e19ec604	\N	2026-09-10	\N	300	0	PHP	manual	cleared	\N	\N	\N	2026-09-01 07:42:27.177+00	2026-09-01 07:42:27.177+00
926a7ca1-0027-4d45-b5bb-106d69adb6ee	c459dd63-add4-42e6-9da4-2a2125730419	expense	Pending buy	98914c49-62d7-4f1e-a186-ab0ebcc70172	\N	c9d6e5bb-53f6-4806-8024-a1b6e19ec604	\N	2026-09-11	\N	999	0	PHP	manual	pending	\N	\N	\N	2026-09-01 07:42:27.187+00	2026-09-01 07:42:27.187+00
39c8f1ca-d45e-42f9-8c2e-7982434795c8	c459dd63-add4-42e6-9da4-2a2125730419	expense	Other spend	db3416c2-c1c4-49fb-9d0a-2e476783b543	\N	c9d6e5bb-53f6-4806-8024-a1b6e19ec604	\N	2026-09-12	\N	500	0	PHP	manual	cleared	\N	\N	\N	2026-09-01 07:42:27.196+00	2026-09-01 07:42:27.196+00
62186bf4-fcd5-4a35-85c9-d122b253d002	c459dd63-add4-42e6-9da4-2a2125730419	expense	Next month	98914c49-62d7-4f1e-a186-ab0ebcc70172	\N	c9d6e5bb-53f6-4806-8024-a1b6e19ec604	\N	2026-10-05	\N	777	0	PHP	manual	cleared	\N	\N	\N	2026-09-01 07:42:27.205+00	2026-09-01 07:42:27.205+00
04e5c250-6100-4fb5-92e7-0676dec89d8a	b9faca84-eff8-413b-a84a-fff402b161ef	expense	Test expense	196c197e-afc4-4f8d-9dc5-be83f2f7be61	\N	eef01f47-b88f-4128-8d30-51b0977a18e0	\N	2026-08-15	\N	50000	0	PHP	manual	cleared	\N	\N	\N	2026-09-01 07:42:27.334+00	2026-09-01 07:42:27.334+00
9699f04e-390c-409b-b649-5ec9572e7c98	547b3c42-5d09-486a-8a86-cb626bc32183	transfer	Goal funding	\N	1b5ccb3b-a4d8-4083-865c-fa82e073f418	0b31b94f-a2ae-4aca-a169-16188c9eb22b	\N	2026-09-01	\N	1000	0	PHP	manual	cleared	\N	goal-overfund-exact	\N	2026-09-01 07:42:27.394+00	2026-09-01 07:42:27.394+00
a0e83a33-d53d-4dbd-9d76-94d9d57a4643	181d14b5-5a57-4432-b64c-629b94cc5b85	expense	Test expense	01d406be-e578-413f-8f9e-69849e2bfd2e	\N	cdc3a9a2-aff9-4cda-8c6d-57262e68e78b	\N	2026-08-15	\N	50000	0	PHP	manual	cleared	\N	\N	\N	2026-09-01 07:42:27.477+00	2026-09-01 07:42:27.477+00
01b925d5-fe03-4966-8d08-118c9d02d080	e641b12c-d43d-4196-b0e6-f0df1b87acc1	expense	Test expense	bc77081d-5450-4cc2-a172-b6884e8c195a	\N	b43a90e0-d8b2-4c87-a7e1-77348528d998	\N	2026-08-15	\N	50000	0	PHP	manual	cleared	\N	\N	\N	2026-09-01 07:42:27.761+00	2026-09-01 07:42:27.761+00
8611e7fa-61c4-41a8-a7a2-68760c6627cf	d48d3f97-0223-44cb-8c8c-6ceec75a083e	transfer	Goal funding	\N	025b2436-166f-4d10-9bbd-86663d7b2fbc	6fe610e6-580a-44d0-aac8-762858f2d5e8	\N	2026-09-01	\N	300	0	PHP	manual	cleared	\N	goal-idem-retry	\N	2026-09-01 07:42:27.877+00	2026-09-01 07:42:27.877+00
f3a6b745-e3f4-48e0-bcc1-9c42fa44d7b8	762339a8-2887-4f3c-bbc0-5117703433ce	transfer	Concurrent goal funding	\N	57c364ee-8c06-4abd-b379-89998454eabe	587998e9-3e7e-435a-8270-8821f470e7c9	\N	2026-09-01	\N	500	0	PHP	manual	cleared	\N	goal-concurrent-b	\N	2026-09-01 07:42:28.269+00	2026-09-01 07:42:28.269+00
7d7f6b73-e7f4-48ea-b80f-be3ebadbefc6	07e727a7-d620-45c6-990a-0a9dc4da7e88	expense	Grocery Store	\N	\N	6efd8d3d-3089-4f80-bfc9-fb26964ea924	\N	2026-09-01	\N	150000	0	PHP	import	cleared	\N	test_1788248547525_qaks1a_expense_1	\N	2026-09-01 07:42:29.78+00	2026-09-01 07:42:29.78+00
384f3462-c1df-426b-b50d-5b56035111db	6dea893a-a41c-4d68-8c8a-37fa9f3baaee	expense	Groceries	6d1e2bd3-7ae7-457f-9393-ff15b89cdf14	\N	57b3a0a6-6b21-4f11-8041-403e49223537	\N	2026-09-10	\N	60000	0	PHP	manual	cleared	\N	\N	\N	2026-09-01 07:42:29.856+00	2026-09-01 07:42:29.856+00
b1b39522-4445-4f73-8d05-5a52543d0056	6dea893a-a41c-4d68-8c8a-37fa9f3baaee	expense	Taxi	75b2324d-2d49-43b0-8d2e-d4a15db870d8	\N	57b3a0a6-6b21-4f11-8041-403e49223537	\N	2026-09-15	\N	40000	0	PHP	manual	cleared	\N	\N	\N	2026-09-01 07:42:29.917+00	2026-09-01 07:42:29.917+00
2f76a224-2578-4207-baa0-c3cf98e43c08	54642217-2a01-4151-9137-e2f05b7134c3	expense	Expense	\N	\N	556367a5-157d-4908-9d6d-87c59a3662bc	\N	2026-09-01	\N	100000	0	PHP	import	cleared	\N	test_1788248547525_qaks1a_expense_idempotent	\N	2026-09-01 07:42:30.094+00	2026-09-01 07:42:30.094+00
\.


--
-- Data for Name: user_preferences; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.user_preferences (user_id, bill_due_reminders, budget_near_limit_warnings, weekly_summary_email, hide_cents, external_ai_enabled, external_ocr_enabled, detailed_ai_context_enabled, created_at, updated_at) FROM stdin;
c0c99378-34f9-415e-92d1-65568519d3cb	t	t	f	f	f	f	f	2026-09-01 07:42:27.11+00	2026-09-01 07:42:27.11+00
b9faca84-eff8-413b-a84a-fff402b161ef	t	t	f	f	f	f	f	2026-09-01 07:42:27.298+00	2026-09-01 07:42:27.298+00
181d14b5-5a57-4432-b64c-629b94cc5b85	t	t	f	f	f	f	f	2026-09-01 07:42:27.453+00	2026-09-01 07:42:27.453+00
e641b12c-d43d-4196-b0e6-f0df1b87acc1	t	t	f	f	f	f	f	2026-09-01 07:42:27.664+00	2026-09-01 07:42:27.664+00
2d53af77-8324-4a23-8deb-1fd28f875d26	t	t	f	f	f	f	f	2026-09-01 07:42:27.683+00	2026-09-01 07:42:27.683+00
37663068-c7d1-41f6-a1f4-f159b7a7b681	t	t	f	f	f	f	f	2026-09-01 07:42:27.99+00	2026-09-01 07:42:27.99+00
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.user_sessions (id, user_id, token_hash, expires_at, last_seen_at, created_at, user_agent) FROM stdin;
39e3f9c4-bb1c-42ce-85b8-c1b5631a8df9	c16888ea-eeeb-4bba-9c45-606b4056aa78	898ea0fafd33b34ef0db7a38c4cbb9f13c897110827a047dcb877481b16c9c3f	2026-09-02 07:42:27.956+00	2026-09-01 07:42:28.178+00	2026-09-01 07:42:27.962+00	\N
68f81089-6fe3-468e-bbdd-500c01ef0790	c67f8063-e14c-4879-8211-60cb93097b78	c131b1a85a5836c52a2ef0fd38f20c67423266ba5a02570f4fe7dbbf995201dd	2026-09-02 07:42:28.931+00	2026-09-01 07:42:28.984+00	2026-09-01 07:42:28.932+00	\N
d3d336c9-fd47-4e1e-ad18-19bd1cc46a92	07e727a7-d620-45c6-990a-0a9dc4da7e88	3464375e745f4f26776aee05ec1986b57c581934f343cda440a41d55a06dfad1	2026-09-02 07:42:29.616+00	2026-09-01 07:42:29.709+00	2026-09-01 07:42:29.618+00	\N
f7f8544a-63f4-475a-bfd8-512550b0a0d3	245edc36-4630-4c3f-a28b-c5933bf8f0f7	cff5ce84904fea6d110320d4106ed88a48b1aedde782262244f2d37451f32373	2026-09-02 07:42:29.057+00	2026-09-01 07:42:29.187+00	2026-09-01 07:42:29.058+00	\N
a9e0ba0b-8600-4de4-8474-4cb7d8b76f86	2ed833e4-a957-47cb-bb83-45e53cf1300e	a9ac7d378b3e28a9c83654097cb996041ef04aa6e61340bf32a4bc627e02e6e6	2026-09-02 07:42:29.28+00	2026-09-01 07:42:29.576+00	2026-09-01 07:42:29.282+00	\N
3dac04b6-81bf-4538-a288-f7ee8aede6a3	e7ab63fc-78a0-4cb2-923d-a2c624b47acd	fa214bb818e59977a326ff4424c5a67884aae549294668839cad7e76e31c70bf	2026-09-02 07:42:30.494+00	2026-09-01 07:42:30.527+00	2026-09-01 07:42:30.495+00	\N
fa1e43f9-841d-4a7f-ba78-0a73d5beaa81	54642217-2a01-4151-9137-e2f05b7134c3	f513f1c6d6bedfc4c8e1f4e7267e7c71419e417db90286dc652cf83fa7a9c537	2026-09-02 07:42:29.898+00	2026-09-01 07:42:30.232+00	2026-09-01 07:42:29.905+00	\N
9ef7aa89-b539-4c7c-8d47-5d0baa3866c2	8fa89f8b-edea-4c2b-ac40-67eaa3b3b92b	3f07de52ab82c4464ba60045f182a22e10b25740dc481bbdfbd75cdb13ece089	2026-09-02 07:42:30.269+00	2026-09-01 07:42:30.304+00	2026-09-01 07:42:30.27+00	\N
b2544cd9-bcc6-40b1-b240-f144ae99f624	da542855-8e6b-42ed-a8b5-ca39e611b6ce	d6642843dee83f209105cc6ee9764e0925e0046446bbbd3c9d8964da78951842	2026-09-02 07:42:30.282+00	2026-09-01 07:42:30.314+00	2026-09-01 07:42:30.284+00	\N
89361d3d-e524-483c-a2bb-8ab1f997baf2	5b97f226-a3d8-45bd-b337-ef6a16f57bbf	716d6ae0e5a5cc82e3f93465d28b82797d982c747cb8a02e6c995f6aa8eb976e	2026-09-02 07:42:30.384+00	2026-09-01 07:42:30.47+00	2026-09-01 07:42:30.388+00	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: monikey
--

COPY public.users (id, email, password_hash, display_name, timezone, base_currency, created_at, updated_at) FROM stdin;
c459dd63-add4-42e6-9da4-2a2125730419	c459dd63-add4-42e6-9da4-2a2125730419@budget-crud.test	test	Budget Test	Asia/Manila	PHP	2026-09-01 07:42:26.713+00	2026-09-01 07:42:26.713+00
c0c99378-34f9-415e-92d1-65568519d3cb	c0c99378-34f9-415e-92d1-65568519d3cb@insights-context.test	test	Insights Test	Asia/Manila	PHP	2026-09-01 07:42:26.746+00	2026-09-01 07:42:26.746+00
e9de0939-7fa9-4618-b6f2-380f180e125e	e9de0939-7fa9-4618-b6f2-380f180e125e@goal-fund.test	test	Goals Test	Asia/Manila	PHP	2026-09-01 07:42:26.786+00	2026-09-01 07:42:26.786+00
b9faca84-eff8-413b-a84a-fff402b161ef	b9faca84-eff8-413b-a84a-fff402b161ef@insights-detailed-false.test	test	Insights Test	Asia/Manila	PHP	2026-09-01 07:42:27.287+00	2026-09-01 07:42:27.287+00
547b3c42-5d09-486a-8a86-cb626bc32183	547b3c42-5d09-486a-8a86-cb626bc32183@goal-overfund.test	test	Goals Test	Asia/Manila	PHP	2026-09-01 07:42:27.338+00	2026-09-01 07:42:27.338+00
181d14b5-5a57-4432-b64c-629b94cc5b85	181d14b5-5a57-4432-b64c-629b94cc5b85@insights-detailed-true.test	test	Insights Test	Asia/Manila	PHP	2026-09-01 07:42:27.44+00	2026-09-01 07:42:27.44+00
32949b3a-9b25-40c2-8979-d3b44a693d5e	32949b3a-9b25-40c2-8979-d3b44a693d5e@budget-alloc-upsert.test	test	Budget Test	Asia/Manila	PHP	2026-09-01 07:42:27.455+00	2026-09-01 07:42:27.455+00
e641b12c-d43d-4196-b0e6-f0df1b87acc1	e641b12c-d43d-4196-b0e6-f0df1b87acc1@insights-user1.test	test	Insights Test	Asia/Manila	PHP	2026-09-01 07:42:27.648+00	2026-09-01 07:42:27.648+00
7509999e-3327-4d5d-93ed-c2ee5eb5db98	7509999e-3327-4d5d-93ed-c2ee5eb5db98@budget-isoA.test	test	Budget Test	Asia/Manila	PHP	2026-09-01 07:42:27.63+00	2026-09-01 07:42:27.63+00
2d53af77-8324-4a23-8deb-1fd28f875d26	2d53af77-8324-4a23-8deb-1fd28f875d26@insights-user2.test	test	Insights Test	Asia/Manila	PHP	2026-09-01 07:42:27.675+00	2026-09-01 07:42:27.675+00
d48d3f97-0223-44cb-8c8c-6ceec75a083e	d48d3f97-0223-44cb-8c8c-6ceec75a083e@goal-idem.test	test	Goals Test	Asia/Manila	PHP	2026-09-01 07:42:27.782+00	2026-09-01 07:42:27.782+00
c16888ea-eeeb-4bba-9c45-606b4056aa78	test-import-1788248547834@example.com	hashed	Import Tester	Asia/Manila	PHP	2026-09-01 07:42:27.944+00	2026-09-01 07:42:27.944+00
37663068-c7d1-41f6-a1f4-f159b7a7b681	37663068-c7d1-41f6-a1f4-f159b7a7b681@insights-stub.test	test	Insights Test	Asia/Manila	PHP	2026-09-01 07:42:27.972+00	2026-09-01 07:42:27.972+00
762339a8-2887-4f3c-bbc0-5117703433ce	762339a8-2887-4f3c-bbc0-5117703433ce@goal-concurrent.test	test	Goals Test	Asia/Manila	PHP	2026-09-01 07:42:28.109+00	2026-09-01 07:42:28.109+00
c67f8063-e14c-4879-8211-60cb93097b78	test-import-1788248548296@example.com	hashed	Import Tester	Asia/Manila	PHP	2026-09-01 07:42:28.305+00	2026-09-01 07:42:28.305+00
245edc36-4630-4c3f-a28b-c5933bf8f0f7	test-dedup-1788248549041@example.com	hashed	Dedup Tester	Asia/Manila	PHP	2026-09-01 07:42:29.043+00	2026-09-01 07:42:29.043+00
2ed833e4-a957-47cb-bb83-45e53cf1300e	test-dedup-1788248549261@example.com	hashed	Dedup Tester	Asia/Manila	PHP	2026-09-01 07:42:29.263+00	2026-09-01 07:42:29.263+00
07e727a7-d620-45c6-990a-0a9dc4da7e88	test-commit-1788248549600@example.com	hashed	Commit Tester	Asia/Manila	PHP	2026-09-01 07:42:29.602+00	2026-09-01 07:42:29.602+00
6dea893a-a41c-4d68-8c8a-37fa9f3baaee	6dea893a-a41c-4d68-8c8a-37fa9f3baaee@reports-budget.test	test	Reports Test	Asia/Manila	PHP	2026-09-01 07:42:29.744+00	2026-09-01 07:42:29.744+00
54642217-2a01-4151-9137-e2f05b7134c3	test-commit-1788248549874@example.com	hashed	Commit Tester	Asia/Manila	PHP	2026-09-01 07:42:29.876+00	2026-09-01 07:42:29.876+00
8fa89f8b-edea-4c2b-ac40-67eaa3b3b92b	user-a-1788248550248@example.com	hashed	User A	Asia/Manila	PHP	2026-09-01 07:42:30.25+00	2026-09-01 07:42:30.25+00
da542855-8e6b-42ed-a8b5-ca39e611b6ce	user-b-1788248550259@example.com	hashed	User B	Asia/Manila	PHP	2026-09-01 07:42:30.261+00	2026-09-01 07:42:30.261+00
5b97f226-a3d8-45bd-b337-ef6a16f57bbf	test-validation-1788248550355@example.com	hashed	Validation Tester	Asia/Manila	PHP	2026-09-01 07:42:30.361+00	2026-09-01 07:42:30.361+00
e7ab63fc-78a0-4cb2-923d-a2c624b47acd	test-validation-1788248550482@example.com	hashed	Validation Tester	Asia/Manila	PHP	2026-09-01 07:42:30.484+00	2026-09-01 07:42:30.484+00
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: budget_allocations budget_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.budget_allocations
    ADD CONSTRAINT budget_allocations_pkey PRIMARY KEY (id);


--
-- Name: budget_periods budget_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.budget_periods
    ADD CONSTRAINT budget_periods_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: credit_card_details credit_card_details_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.credit_card_details
    ADD CONSTRAINT credit_card_details_pkey PRIMARY KEY (account_id);


--
-- Name: daily_finance_snapshots daily_finance_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.daily_finance_snapshots
    ADD CONSTRAINT daily_finance_snapshots_pkey PRIMARY KEY (user_id, snapshot_date);


--
-- Name: dividends dividends_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.dividends
    ADD CONSTRAINT dividends_pkey PRIMARY KEY (id);


--
-- Name: external_api_usage external_api_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.external_api_usage
    ADD CONSTRAINT external_api_usage_pkey PRIMARY KEY (id);


--
-- Name: financial_accounts financial_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.financial_accounts
    ADD CONSTRAINT financial_accounts_pkey PRIMARY KEY (id);


--
-- Name: fx_rate_snapshots fx_rate_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.fx_rate_snapshots
    ADD CONSTRAINT fx_rate_snapshots_pkey PRIMARY KEY (base_currency, quote_currency, rate_date, provider);


--
-- Name: goal_contributions goal_contributions_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.goal_contributions
    ADD CONSTRAINT goal_contributions_pkey PRIMARY KEY (id);


--
-- Name: goals goals_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_pkey PRIMARY KEY (id);


--
-- Name: import_batches import_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_pkey PRIMARY KEY (id);


--
-- Name: imported_transactions imported_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.imported_transactions
    ADD CONSTRAINT imported_transactions_pkey PRIMARY KEY (id);


--
-- Name: imported_transactions imported_transactions_provider_dedup_key_unique; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.imported_transactions
    ADD CONSTRAINT imported_transactions_provider_dedup_key_unique UNIQUE (provider, dedup_key);


--
-- Name: instruments instruments_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.instruments
    ADD CONSTRAINT instruments_pkey PRIMARY KEY (id);


--
-- Name: investment_trades investment_trades_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.investment_trades
    ADD CONSTRAINT investment_trades_pkey PRIMARY KEY (id);


--
-- Name: notification_outbox notification_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.notification_outbox
    ADD CONSTRAINT notification_outbox_pkey PRIMARY KEY (id);


--
-- Name: plaid_items plaid_items_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.plaid_items
    ADD CONSTRAINT plaid_items_pkey PRIMARY KEY (id);


--
-- Name: plaid_link_tokens plaid_link_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.plaid_link_tokens
    ADD CONSTRAINT plaid_link_tokens_pkey PRIMARY KEY (id);


--
-- Name: postings postings_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.postings
    ADD CONSTRAINT postings_pkey PRIMARY KEY (id);


--
-- Name: quote_snapshots quote_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.quote_snapshots
    ADD CONSTRAINT quote_snapshots_pkey PRIMARY KEY (id);


--
-- Name: receipts receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.receipts
    ADD CONSTRAINT receipts_pkey PRIMARY KEY (id);


--
-- Name: recurring_items recurring_items_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.recurring_items
    ADD CONSTRAINT recurring_items_pkey PRIMARY KEY (id);


--
-- Name: transaction_balance_effects transaction_balance_effects_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.transaction_balance_effects
    ADD CONSTRAINT transaction_balance_effects_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: user_preferences user_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_pkey PRIMARY KEY (user_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: budget_allocations_budget_period_id_category_id_key; Type: INDEX; Schema: public; Owner: monikey
--

CREATE UNIQUE INDEX budget_allocations_budget_period_id_category_id_key ON public.budget_allocations USING btree (budget_period_id, category_id);


--
-- Name: budget_periods_user_id_period_start_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX budget_periods_user_id_period_start_idx ON public.budget_periods USING btree (user_id, period_start);


--
-- Name: budget_periods_user_id_period_start_period_end_key; Type: INDEX; Schema: public; Owner: monikey
--

CREATE UNIQUE INDEX budget_periods_user_id_period_start_period_end_key ON public.budget_periods USING btree (user_id, period_start, period_end);


--
-- Name: categories_user_id_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX categories_user_id_idx ON public.categories USING btree (user_id);


--
-- Name: daily_finance_snapshots_user_id_snapshot_date_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX daily_finance_snapshots_user_id_snapshot_date_idx ON public.daily_finance_snapshots USING btree (user_id, snapshot_date DESC);


--
-- Name: dividends_user_id_instrument_id_occurred_on_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX dividends_user_id_instrument_id_occurred_on_idx ON public.dividends USING btree (user_id, instrument_id, occurred_on);


--
-- Name: external_api_usage_provider_period_operation_key; Type: INDEX; Schema: public; Owner: monikey
--

CREATE UNIQUE INDEX external_api_usage_provider_period_operation_key ON public.external_api_usage USING btree (provider, period, operation);


--
-- Name: financial_accounts_user_id_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX financial_accounts_user_id_idx ON public.financial_accounts USING btree (user_id);


--
-- Name: goal_contributions_goal_id_created_at_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX goal_contributions_goal_id_created_at_idx ON public.goal_contributions USING btree (goal_id, created_at);


--
-- Name: goal_contributions_transaction_id_key; Type: INDEX; Schema: public; Owner: monikey
--

CREATE UNIQUE INDEX goal_contributions_transaction_id_key ON public.goal_contributions USING btree (transaction_id);


--
-- Name: goals_user_id_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX goals_user_id_idx ON public.goals USING btree (user_id);


--
-- Name: import_batches_user_id_matched_account_id_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX import_batches_user_id_matched_account_id_idx ON public.import_batches USING btree (user_id, matched_account_id);


--
-- Name: import_batches_user_id_status_created_at_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX import_batches_user_id_status_created_at_idx ON public.import_batches USING btree (user_id, status, created_at DESC);


--
-- Name: imported_transactions_import_batch_id_dedup_key_key; Type: INDEX; Schema: public; Owner: monikey
--

CREATE UNIQUE INDEX imported_transactions_import_batch_id_dedup_key_key ON public.imported_transactions USING btree (import_batch_id, dedup_key);


--
-- Name: imported_transactions_import_batch_id_status_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX imported_transactions_import_batch_id_status_idx ON public.imported_transactions USING btree (import_batch_id, status);


--
-- Name: instruments_ticker_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX instruments_ticker_idx ON public.instruments USING btree (ticker);


--
-- Name: instruments_user_id_ticker_key; Type: INDEX; Schema: public; Owner: monikey
--

CREATE UNIQUE INDEX instruments_user_id_ticker_key ON public.instruments USING btree (user_id, ticker);


--
-- Name: investment_trades_user_id_idempotency_key_key; Type: INDEX; Schema: public; Owner: monikey
--

CREATE UNIQUE INDEX investment_trades_user_id_idempotency_key_key ON public.investment_trades USING btree (user_id, idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: investment_trades_user_id_instrument_id_occurred_on_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX investment_trades_user_id_instrument_id_occurred_on_idx ON public.investment_trades USING btree (user_id, instrument_id, occurred_on);


--
-- Name: ix_fx_rate_snapshots_date; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX ix_fx_rate_snapshots_date ON public.fx_rate_snapshots USING btree (base_currency, quote_currency, rate_date DESC);


--
-- Name: ix_fx_rate_snapshots_provider; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX ix_fx_rate_snapshots_provider ON public.fx_rate_snapshots USING btree (provider, rate_date DESC);


--
-- Name: notification_outbox_dedupe_key_key; Type: INDEX; Schema: public; Owner: monikey
--

CREATE UNIQUE INDEX notification_outbox_dedupe_key_key ON public.notification_outbox USING btree (dedupe_key);


--
-- Name: notification_outbox_status_available_at_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX notification_outbox_status_available_at_idx ON public.notification_outbox USING btree (status, available_at);


--
-- Name: notification_outbox_user_id_kind_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX notification_outbox_user_id_kind_idx ON public.notification_outbox USING btree (user_id, kind);


--
-- Name: plaid_items_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX plaid_items_user_id_created_at_idx ON public.plaid_items USING btree (user_id, created_at DESC);


--
-- Name: plaid_items_user_id_item_id_key; Type: INDEX; Schema: public; Owner: monikey
--

CREATE UNIQUE INDEX plaid_items_user_id_item_id_key ON public.plaid_items USING btree (user_id, item_id);


--
-- Name: plaid_link_tokens_link_token_key; Type: INDEX; Schema: public; Owner: monikey
--

CREATE UNIQUE INDEX plaid_link_tokens_link_token_key ON public.plaid_link_tokens USING btree (link_token);


--
-- Name: plaid_link_tokens_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX plaid_link_tokens_user_id_created_at_idx ON public.plaid_link_tokens USING btree (user_id, created_at);


--
-- Name: postings_imported_transaction_id_key; Type: INDEX; Schema: public; Owner: monikey
--

CREATE UNIQUE INDEX postings_imported_transaction_id_key ON public.postings USING btree (imported_transaction_id);


--
-- Name: postings_transaction_id_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX postings_transaction_id_idx ON public.postings USING btree (transaction_id);


--
-- Name: postings_transaction_id_key; Type: INDEX; Schema: public; Owner: monikey
--

CREATE UNIQUE INDEX postings_transaction_id_key ON public.postings USING btree (transaction_id);


--
-- Name: quote_snapshots_instrument_id_fetched_at_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX quote_snapshots_instrument_id_fetched_at_idx ON public.quote_snapshots USING btree (instrument_id, fetched_at);


--
-- Name: receipts_status_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX receipts_status_idx ON public.receipts USING btree (status);


--
-- Name: receipts_transaction_id_key; Type: INDEX; Schema: public; Owner: monikey
--

CREATE UNIQUE INDEX receipts_transaction_id_key ON public.receipts USING btree (transaction_id);


--
-- Name: receipts_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX receipts_user_id_created_at_idx ON public.receipts USING btree (user_id, created_at);


--
-- Name: recurring_items_user_id_next_due_date_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX recurring_items_user_id_next_due_date_idx ON public.recurring_items USING btree (user_id, next_due_date);


--
-- Name: recurring_items_user_id_status_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX recurring_items_user_id_status_idx ON public.recurring_items USING btree (user_id, status);


--
-- Name: transaction_balance_effects_account_id_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX transaction_balance_effects_account_id_idx ON public.transaction_balance_effects USING btree (account_id);


--
-- Name: transaction_balance_effects_transaction_id_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX transaction_balance_effects_transaction_id_idx ON public.transaction_balance_effects USING btree (transaction_id);


--
-- Name: transactions_user_id_category_id_occurred_on_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX transactions_user_id_category_id_occurred_on_idx ON public.transactions USING btree (user_id, category_id, occurred_on);


--
-- Name: transactions_user_id_idempotency_key_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE UNIQUE INDEX transactions_user_id_idempotency_key_idx ON public.transactions USING btree (user_id, idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: transactions_user_id_occurred_on_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX transactions_user_id_occurred_on_idx ON public.transactions USING btree (user_id, occurred_on DESC);


--
-- Name: user_sessions_expires_at_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX user_sessions_expires_at_idx ON public.user_sessions USING btree (expires_at);


--
-- Name: user_sessions_token_hash_key; Type: INDEX; Schema: public; Owner: monikey
--

CREATE UNIQUE INDEX user_sessions_token_hash_key ON public.user_sessions USING btree (token_hash);


--
-- Name: user_sessions_user_id_idx; Type: INDEX; Schema: public; Owner: monikey
--

CREATE INDEX user_sessions_user_id_idx ON public.user_sessions USING btree (user_id);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: monikey
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: credit_card_details credit_card_details_invariants; Type: TRIGGER; Schema: public; Owner: monikey
--

CREATE CONSTRAINT TRIGGER credit_card_details_invariants AFTER INSERT OR UPDATE ON public.credit_card_details DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.enforce_credit_card_details_invariants();


--
-- Name: credit_card_details credit_card_details_prevent_orphan; Type: TRIGGER; Schema: public; Owner: monikey
--

CREATE TRIGGER credit_card_details_prevent_orphan BEFORE DELETE ON public.credit_card_details FOR EACH ROW EXECUTE FUNCTION public.prevent_orphaning_live_credit_card();


--
-- Name: financial_accounts financial_accounts_card_invariants; Type: TRIGGER; Schema: public; Owner: monikey
--

CREATE CONSTRAINT TRIGGER financial_accounts_card_invariants AFTER INSERT OR UPDATE ON public.financial_accounts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.enforce_financial_account_card_invariants();


--
-- Name: goals goals_updated_at; Type: TRIGGER; Schema: public; Owner: monikey
--

CREATE TRIGGER goals_updated_at BEFORE UPDATE ON public.goals FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: import_batches import_batches_updated_at_trigger; Type: TRIGGER; Schema: public; Owner: monikey
--

CREATE TRIGGER import_batches_updated_at_trigger BEFORE UPDATE ON public.import_batches FOR EACH ROW EXECUTE FUNCTION public.update_import_batches_updated_at();


--
-- Name: plaid_items plaid_items_updated_at_trigger; Type: TRIGGER; Schema: public; Owner: monikey
--

CREATE TRIGGER plaid_items_updated_at_trigger BEFORE UPDATE ON public.plaid_items FOR EACH ROW EXECUTE FUNCTION public.update_plaid_items_updated_at();


--
-- Name: transactions transactions_updated_at; Type: TRIGGER; Schema: public; Owner: monikey
--

CREATE TRIGGER transactions_updated_at BEFORE UPDATE ON public.transactions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: budget_allocations budget_allocations_budget_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.budget_allocations
    ADD CONSTRAINT budget_allocations_budget_period_id_fkey FOREIGN KEY (budget_period_id) REFERENCES public.budget_periods(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: budget_allocations budget_allocations_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.budget_allocations
    ADD CONSTRAINT budget_allocations_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: budget_periods budget_periods_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.budget_periods
    ADD CONSTRAINT budget_periods_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: categories categories_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: credit_card_details credit_card_details_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.credit_card_details
    ADD CONSTRAINT credit_card_details_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.financial_accounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dividends dividends_instrument_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.dividends
    ADD CONSTRAINT dividends_instrument_id_fkey FOREIGN KEY (instrument_id) REFERENCES public.instruments(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: dividends dividends_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.dividends
    ADD CONSTRAINT dividends_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: financial_accounts financial_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.financial_accounts
    ADD CONSTRAINT financial_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: goal_contributions goal_contributions_goal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.goal_contributions
    ADD CONSTRAINT goal_contributions_goal_id_fkey FOREIGN KEY (goal_id) REFERENCES public.goals(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: goal_contributions goal_contributions_source_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.goal_contributions
    ADD CONSTRAINT goal_contributions_source_account_id_fkey FOREIGN KEY (source_account_id) REFERENCES public.financial_accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: goal_contributions goal_contributions_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.goal_contributions
    ADD CONSTRAINT goal_contributions_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: goals goals_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: import_batches import_batches_import_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_import_source_id_fkey FOREIGN KEY (import_source_id) REFERENCES public.plaid_items(id) ON DELETE SET NULL;


--
-- Name: import_batches import_batches_matched_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_matched_account_id_fkey FOREIGN KEY (matched_account_id) REFERENCES public.financial_accounts(id) ON DELETE SET NULL;


--
-- Name: import_batches import_batches_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: imported_transactions imported_transactions_import_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.imported_transactions
    ADD CONSTRAINT imported_transactions_import_batch_id_fkey FOREIGN KEY (import_batch_id) REFERENCES public.import_batches(id) ON DELETE CASCADE;


--
-- Name: instruments instruments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.instruments
    ADD CONSTRAINT instruments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: investment_trades investment_trades_cash_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.investment_trades
    ADD CONSTRAINT investment_trades_cash_account_id_fkey FOREIGN KEY (cash_account_id) REFERENCES public.financial_accounts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: investment_trades investment_trades_instrument_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.investment_trades
    ADD CONSTRAINT investment_trades_instrument_id_fkey FOREIGN KEY (instrument_id) REFERENCES public.instruments(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: investment_trades investment_trades_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.investment_trades
    ADD CONSTRAINT investment_trades_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notification_outbox notification_outbox_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.notification_outbox
    ADD CONSTRAINT notification_outbox_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: plaid_items plaid_items_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.plaid_items
    ADD CONSTRAINT plaid_items_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: plaid_link_tokens plaid_link_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.plaid_link_tokens
    ADD CONSTRAINT plaid_link_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: postings postings_imported_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.postings
    ADD CONSTRAINT postings_imported_transaction_id_fkey FOREIGN KEY (imported_transaction_id) REFERENCES public.imported_transactions(id) ON DELETE CASCADE;


--
-- Name: postings postings_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.postings
    ADD CONSTRAINT postings_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(id) ON DELETE CASCADE;


--
-- Name: quote_snapshots quote_snapshots_instrument_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.quote_snapshots
    ADD CONSTRAINT quote_snapshots_instrument_id_fkey FOREIGN KEY (instrument_id) REFERENCES public.instruments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: receipts receipts_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.receipts
    ADD CONSTRAINT receipts_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(id) ON DELETE SET NULL;


--
-- Name: receipts receipts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.receipts
    ADD CONSTRAINT receipts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: recurring_items recurring_items_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.recurring_items
    ADD CONSTRAINT recurring_items_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.financial_accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: recurring_items recurring_items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.recurring_items
    ADD CONSTRAINT recurring_items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: recurring_items recurring_items_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.recurring_items
    ADD CONSTRAINT recurring_items_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transaction_balance_effects transaction_balance_effects_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.transaction_balance_effects
    ADD CONSTRAINT transaction_balance_effects_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.financial_accounts(id) ON DELETE CASCADE;


--
-- Name: transaction_balance_effects transaction_balance_effects_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.transaction_balance_effects
    ADD CONSTRAINT transaction_balance_effects_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE SET NULL;


--
-- Name: transactions transactions_from_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_from_account_id_fkey FOREIGN KEY (from_account_id) REFERENCES public.financial_accounts(id) ON DELETE SET NULL;


--
-- Name: transactions transactions_goal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_goal_id_fkey FOREIGN KEY (goal_id) REFERENCES public.goals(id) ON DELETE SET NULL;


--
-- Name: transactions transactions_reversed_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_reversed_transaction_id_fkey FOREIGN KEY (reversed_transaction_id) REFERENCES public.transactions(id) ON DELETE SET NULL;


--
-- Name: transactions transactions_to_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_to_account_id_fkey FOREIGN KEY (to_account_id) REFERENCES public.financial_accounts(id) ON DELETE SET NULL;


--
-- Name: transactions transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_preferences user_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: monikey
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict hA7j2oDaKR2nVbBjaLrwSWLykOXvddP9eUf2dtyjNjIWfevGbJ2fh7OAdlXugwA

